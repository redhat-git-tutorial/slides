#!/bin/sh

git init --bare upstream
git clone upstream bob
git clone upstream alice

(
cd alice
git config user.name Alice
git config user.email alice@example.com
)

(
cd bob
git config user.name Bob
git config user.email bob@example.com
)

