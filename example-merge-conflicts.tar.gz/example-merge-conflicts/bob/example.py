def main():
    print('Hello Boston!')
    print('This is a very contrived example.')

if __name__ == '__main__':
    main()
